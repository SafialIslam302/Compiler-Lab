import mathematical.h
import exchangeInfo.h
global perfectNumber a -> 10 |
perfectNumber main<>
<<
	perfectNumber b # r # e |
	littlefloat e |
	perfectNumber b |
	a <<< 10 >>> |
	a <<< 5 # 5 >>> |
	z -> 100 |
	a -> 5.6 |
	outPut a |
	b -> 3 | 
	r -> a + b |
	outPut r |
	e -> a * b + 10 |
	outPut e |
				
	ifhappen < a { b >
		b |
	either
		a |
					
	ifhappen < r { 10 >
		fac < 2 > |
					
	sine < 30 > |
	cosine < 30 > |
	tangent < 30 > |
	elog < 5 > |
	fac < 4 > |
	prime < 20 # 30 > |
	gcd < 10 # 5> |
	lcm < 10 # 5> |
	fibol < 9 > |
	fibon < 9 > |
	root < 1 # -5 # 5 > |
	binary < 100 > |
	ncr < 10 # 3 > |
	npr < 10 # 3 > |
				
				
	forloop < a -> 0 | a { 11 | a ^+ >
	<<
		a  |
	>>
				
	forloop < a -> 10 | a }-> 5 | a ^- >
	<<
		a  |
	>>
				
	perfectNumber k # h # j # p | 
	forloop < c -> 0 | a { 10 | a ^+ > |
	forloop < i -> 0 | i { 5 | i ^+ >
	<<
		forloop < h -> 2 | h { 10 | h ^+ >
		<<
			20 + 10 |
		>>
		e -> 10 |
	>>
				
				
	whileloop < a { 10 >
	<<
		k -> 10 |
	>>
						
	a -> 3 |	
	select < a >
	<<	
		event 1 ? 10 * 6   | interrupt |
		event 2 ? 10 * 7   | interrupt |
		event 3 ? 5  + 49  | interrupt |
		event 4 ? 40 + 50  | interrupt |
        event 5 ? 100 + 0  | interrupt |
        event 6 ? 45 + 54  | interrupt |
		noevent ? 10 + 10  | interrupt |
	>>

	perfectNumber g # f |
	g -> 1 |
	f -> 0 |
	outPut g |
	outPut f |
	g /& f |
	g /| f |
	/! g |
	/! f |	
				
>>	