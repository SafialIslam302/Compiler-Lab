#include <stdio.h>
#include <math.h>

int num_keyword=0,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,a16,a17,a18,a19,
	a20,a21,a22,a23,a24,a25,a26,a27,a28,a29,a30,a31,a32,a33;
int num_arithmatic=0,b1,b2,b3,b4,b5;
int num_unary=0,c1,c2,c3,c4;
int num_relation=0,d1,d2,d3,d4,d5,d6;
int num_logical=0,e1,e2,e3;
int num_assignment=0,f1,f2,f3,f4,f5,f6;
int num_predefinefunction=0,g1,g2;
int num_special=0,h1,h2,h3,h4,h5,h6,h7,h8,h9,h10,h11;
int num_puncuation=0,i1,i2,i3,i4;
int num_branch=0,k1,k2,k3,k4,k5,k6;
int num_headerfile=0;
int num_int=0;
int num_double=0;
int num_identifier=0;